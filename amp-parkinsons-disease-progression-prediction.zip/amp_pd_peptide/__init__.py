
from .competition import make_env

__all__ = ['make_env']
